System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Student;
    return {
        setters:[],
        execute: function() {
            Student = (function () {
                function Student() {
                    this.id = 0;
                    this.name = "";
                }
                return Student;
            }());
            exports_1("Student", Student);
        }
    }
});
//# sourceMappingURL=student.js.map