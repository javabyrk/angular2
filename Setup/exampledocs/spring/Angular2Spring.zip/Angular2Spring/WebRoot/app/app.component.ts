﻿import { Component } from '@angular/core';
import { UserService } from './user.service';

@Component({
    selector: "user-app",
    templateUrl: "app/app.component.html",
    providers: [UserService]
})

export class AppComponent{
    message: string;
    users;

  constructor(private userService: UserService) {
  	this.userService.getUsers().subscribe( users => this.users = users);
  }
  
}
