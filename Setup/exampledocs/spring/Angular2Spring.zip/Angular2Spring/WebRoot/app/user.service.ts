﻿import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Injectable()
export class UserService {
  private appUrl = 'http://localhost:8080/Angular2Spring/rest/user/';
  constructor (private http: Http) {}
  
  getUsers(){
    return this.http.get(this.appUrl).map(res => res.json());
  }

}
